import { Component, OnInit } from '@angular/core';
import { Album } from 'src/app/model/album';
import { AlbumService } from 'src/app/service/album.service';

@Component({
  selector: 'app-opcao1',
  templateUrl: './opcao1.component.html',
  styleUrls: ['./opcao1.component.css']
})
export class Opcao1Component implements OnInit {

  contador: number = 0;
  nome: String = "";
  mensagem: String = "";
  vetAlbuns: Album[] = [];
  vAlbum: Album = {
    id: 0,
    userId: 0,
    title: ""
  };

  vAltAlbum: Album = {
    id: 0,
    userId: 0,
    title: ""
  };

  idAlbum: number = 0;

  /*[
    {
      id: 1,
      userId: 1,
      title: "Título 1"
    },
    {
      id: 2,
      userId: 1,
      title: "Título 2"
    },
    {
      id: 3,
      userId: 1,
      title: "Título 3"
    }
  ];*/

  constructor(private albumService: AlbumService) { }

  ngOnInit(): void {
    this.albumService.getAll().subscribe(
      resposta => {
        console.log(resposta);
        this.vetAlbuns = resposta;
      }
    );

    this.albumService.getById(1).subscribe(
      resposta => {
        this.vAlbum = resposta;
      }
    );
  }

  incContador(): void {
    this.contador++;
  }

  analisaNome(): void {
    this.mensagem = "O campo 'nome' possui "+this.nome.length+" caracteres.";
  }

  getByIdLocal(): void {
    this.albumService.getById(this.idAlbum).subscribe(
      resposta => this.vAlbum = resposta
    );
  }

  insAlbumLocal(): void {
    this.albumService.insAlbum(this.vAlbum).subscribe(
      resposta => this.vAlbum = resposta
    );
  }

  updAlbumLocal(): void {
    this.albumService.updAlbum(this.vAlbum).subscribe(
      resposta => this.vAltAlbum = resposta
    );
  }

  delAlbumLocal(): void {
    this.albumService.delAlbum(this.vAlbum.id!).subscribe({
      next: resposta => this.mensagem = "Álbum deletado!",
      error: erro => this.mensagem = "Houve erro!"
    });
  }

}
