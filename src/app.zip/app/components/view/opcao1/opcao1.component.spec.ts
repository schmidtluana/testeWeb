import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Opcao1Component } from './opcao1.component';

describe('Opcao1Component', () => {
  let component: Opcao1Component;
  let fixture: ComponentFixture<Opcao1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Opcao1Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Opcao1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
