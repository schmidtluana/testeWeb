export interface Album {
    id?: number; //? indica campo opcional.
    userId: number;
    title: String;
}
